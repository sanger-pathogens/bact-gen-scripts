int ssaha_init( char **argv, int argc, int SEG_LEN);
